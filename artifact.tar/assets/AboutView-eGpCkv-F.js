import{d as e,c as a,a as o,_ as t,o as s}from"./index-CZc558C7.js";const c={class:"about"},m=e({__name:"AboutView",setup(_){return(n,r)=>(s(),a("div",c,[o(t)]))}});export{m as default};
